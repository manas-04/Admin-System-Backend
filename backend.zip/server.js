const express = require("express");
const bodyParser = require("body-parser");
require("dotenv").config();

const loginRouter = require("./router/completeRouter");

const db = require("./db");

const app = express();
app.use(express.json());
app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.urlencoded({ extended: false }));
app.use(loginRouter);
app.use(function (req, res, next) {
    res.setHeader("Access-Control-Allow-Origin", '*');
    res.setHeader('Access-Control-Allow-Methods', 'POST,GET,OPTIONS,PUT,DELETE');
    res.setHeader('Access-Control-Allow-Headers', 'Content-Type,Accept');
    next();
});

app.get('/', (req,res) => {
    res.send(`<h1>API RUNNING</h1>`);
});

db.then(connection => {
    if(connection){
        console.log("Server connected.");
        app.listen(process.env.PORT || 4000,function(){
            console.log("Server listening at port " + process.env.PORT);
        });
    }
}).catch(err => {
    console.log(err);
});